#pragma once

// =============================================================================
// PUBG Mobile Global 4.7.0 (4.7.0 -- 64-Bit) SDK
// Copyright (C) 2026 Zervex RIYAZ. All Rights Reserved.
// Developed by: @Zervexcheat RIYAZ (TG: @RIYAZXERO | Channel: @RIYAZ_STUFF)
// GitHub: https://github.com/RIYAZXERO
// Generation Time: Thu Nov 12 22:34:24 2026

// =============================================================================

namespace SDK
{
//---------------------------------------------------------------------------
// Script Structs
//---------------------------------------------------------------------------

// UserDefinedStruct BP_STRUCT_WeaponAttrBPTable_type.BP_STRUCT_WeaponAttrBPTable_type
// 0x006D
struct FBP_STRUCT_WeaponAttrBPTable_type
{
	struct FString                                     AttachmentSkinIDList_1_68C117003440A0EE1A2DDA300D678804;  // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                BPID_2_5A4F6D006A4E746E1527F1660046AA94;                  // 0x0010(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0014(0x0004) MISSED OFFSET
	TArray<int>                                        AttachmentIDList_a_5_6E7001C028E30A41653FBE36025F1751;    // 0x0018(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	TArray<int>                                        ParentIDList_a_6_3486FA0030D9987A663B62F90FFCB731;        // 0x0028(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     DeadInventoryBoxPath_7_1883E1C0339C8C7958767FF2080EC2C8;  // 0x0038(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                PendantID_8_32B77B0039C6C1D620F9E77400A423B4;             // 0x0048(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x004C(0x0004) MISSED OFFSET
	struct FString                                     DeadInventoryBoxIDs_10_7CB7FE8050FC74B432EE0A820680F713;  // 0x0050(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	float                                              CheckWeaponSkillDuration_f_11_6111F9C073ADAB21228400A10010AD36;// 0x0060(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                WeaponSkillID_12_225B82C01AF0B81B520FC56F0A446294;        // 0x0064(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              WeaponHighlightMomentDuration_f_13_2B4B248076F9F3364A96A40101AE5A46;// 0x0068(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               CheckWeaponSkillHideOriginWeapon_14_77240A001FC4CCD215F871EB0113E89E;// 0x006C(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

}

